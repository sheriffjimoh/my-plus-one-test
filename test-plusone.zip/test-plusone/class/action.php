<?php 
require 'controller.php';
session_start();


$obj = new Main;


// insert data here....
  if (isset($_POST['submit'])) {
  $fname = $_POST['name'];
   $age = $_POST['dob'];
  
   if ($obj->group_name($fname) =='exist') {
   		header("LOCATION:../index.php");
  	   $_SESSION['error']='this student already exist in a  group';
   }else{
   	 $group_name = $obj->group_name($fname);
   }
 $insert_data  = $obj->Insert_student_records($fname,$age,$group_name);


 if ($insert_data) {
 	
  	header("LOCATION:../index.php");
  	echo $group_name;
   $_SESSION['success']='inserted successfull'.$group_name	;
 	 }else{
 	 	header("LOCATION:../index.php?msg=something went wrong"); 	 }

}



 ?>