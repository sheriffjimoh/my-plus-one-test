<?php
 require "db.php";
/**
 * main classs
 */
/**
 * 
 */
class Main extends DBH
{
	
	 

	public function  Insert_student_records($name,$dob,$group)
	{
       $dateOfBirth = $dob;
     $today = date("Y-m-d");
     $diff = date_diff(date_create($dateOfBirth), date_create($today));
      $age =  $diff->format('%y');

		$round ="st".rand(34554,44433);
		$student_id =$round;
		  
		  $time = time();
		  $date = Date("Y-m-d", $time);
		 $STH = $this->Connect()->prepare("INSERT INTO students  (Fullname,Dob,Age,Student_id,Student_group,Date) VALUES (:name,:dob,:age,:student_id,:student_group,:date)");
           $execute=$STH->execute(array(':name' =>$name,':dob' =>$dob,':age' =>$age,':student_id' =>$student_id, ':student_group' =>$group,':date' =>$date));
           if ($execute) {
           	return true;
        }

	}

	 public function  group_name($newname)
	 {         

	 	     $group_name ="group".rand(9987,5654);
   	 	   $STH = $this->Connect()->query("SELECT * FROM  students order by id desc");
           $row = $STH->fetch();
           $stu_group_name = $row['Student_group'];
           $name = $row['Fullname'];
           $student_id =$row['id'];
	 	  $STHg = $this->Connect()->query("SELECT * FROM  students where Student_group='$stu_group_name'");
              if ($STHg->rowCount() == 0) {
              	  return  'group 1';
             }else if ($STHg->rowCount() > 0 && $STHg->rowCount() < 3) {
            $STHg2 = $this->Connect()->query("SELECT * FROM  students where Fullname ='$newname' and Student_group='$stu_group_name' ");
            if ($STHg2->rowCount() > 0 ){

                  return "exist";
            }else{
          $STHg2 = $this->Connect()->query("SELECT * FROM  students where Fullname='$newname' ");
               
                 if ($STHg2->rowCount() > 0 ){

                  return "exist";
            }else{
            	 return $stu_group_name;
            	}

            }

                        	 
             }else if ($STHg->rowCount() == 3) {
             $STHg2 = $this->Connect()->query("SELECT * FROM  students where Fullname='$newname' ");

             if ($STHg2->rowCount() > 0 ){

                  return "exist";
            }else{
            	return "group".$student_id;

            	}
             	              }


	 }

	    public function show_student($group_name)
	    {
	    	  try {
        $STH = $this->Connect()->query("SELECT * FROM  students where student_group ='$group_name' order by Student_group desc  ");
              if ($STH->rowCount() > 0) {
                while ($row = $STH->fetch()) {
                  $array[] = $row;
                                             }
                 return $array;          
                                        }
                  } catch (Exception $e) {
          echo "Error:". $e->getmessage();
                  }
	    }
	    public function show_groups()
	    {
	    	  try {
        $STH = $this->Connect()->query("SELECT * FROM  students group by Student_group desc  ");
              if ($STH->rowCount() > 0) {
                while ($row = $STH->fetch()) {
                  $array[] = $row;
                                             }
                 return $array;          
                                        }
                  } catch (Exception $e) {
          echo "Error:". $e->getmessage();
                  }
	    }


	  public function students_age($date)
	  {  
	  	
	  $dateOfBirth = $date;
     $today = date("Y-m-d");
     $diff = date_diff(date_create($dateOfBirth), date_create($today));
      return $diff->format('%y');
		
	  }
           
           public function oder_age($group)
	  {  
	  	  $sql ="SELECT * FROM  students  where Age=(SELECT MAX(Age) FROM Students WHERE Student_group='$group')";
            $query =$this->Connect()->query($sql);
                $row=$query->fetch();

                return $row;

   } 
        public function sum_age($group)
	  {  
	  	  $sql ="SELECT SUM(Age) as total_age FROM Students WHERE Student_group='$group'";
            $query =$this->Connect()->query($sql);
                $row=$query->fetch();

                return $row;

   }
    public function Arrayperser($n,$m)
    {
 
       }

}