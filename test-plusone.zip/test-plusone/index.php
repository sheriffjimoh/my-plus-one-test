<?php session_start();

include 'class/controller.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>plus one test Q:2</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
</head>
<style type="text/css">
	fieldset{
		margin: 120px;
	}
</style>
<bod>	

	<fieldset class="col-lg-8 offset-lg-2">

    <!-- question 1-->

      <div>
      	<h3>My question 1</h3>

      	<!-- i used two array of students group and students data to form one multidimention associative array -->
      	 <?php 
      
             
                   $obj = new Main;
			  	$data_sgroup= $obj->show_groups();
                 foreach ($data_sgroup as $name) {

                     $data =   $obj->show_student($name['Student_group']);
                 	 	foreach ($data as $key => $value) {
             	 	   	$arr= array($name['Student_group'] =>array($key = $value)) ;
             	 	   	 echo "<pre>";
                       print_r(	$arr);
                         }
                        
      	

              }

           
      	 ?>
      </div>



















		<?php if (isset($_SESSION['success'])) {
             echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
		}
		?><?php if (isset($_SESSION['error'])) {
             echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
		}
		?>


		<?php 
		  ?>
    <hr>
		<h3> Question 2 : Student Registeration fields </h3>
		<form  class="form-group"  method="post" action="class/action.php">
			<div class="form-group">
			<input type="text" name="name" class="form-control" placeholder="Enter Your Fullname" required="">
		     </div> 
		     <div class="form-group">
			<input type="date" name="dob" class="form-control" placeholder="Enter Your Date Of brirth" required="">
		     </div>
		     <div class="form-group">
			<input type="submit" name="submit" class="btn btn-primary">
		</div>
		</form>
		<hr>
		<h3>Students Datas</h3>
		<h6>1. The groups: with the names and age of its members.</h6>

		<hr>
		 <table class="table table-responsive table-hover" border="2">
			  
			  <thead>
			  	<th>#</th>
			  	<th>Fullname</th>
			  	<th>DOB</th>
			  	<th>Student ID</th>
			  	<th>Added date</th>
			  </thead>

			  <tbody>

			  	<?php 
			  	$obj = new Main;
                   //  get all student but diplay only group name
			  	$data = $obj->show_groups();
                 $srno = 0;
         if ($data > 0) {
            foreach ($data as $row) {
              $srno ++;
			  		?>
			  		<tr>
			  			<td  colspan="6"  align="center" style="background: #f2f2f2; color:green; font-weight: bolder;"><?php echo $row['Student_group']  ?></td>
			  		</tr>
			  		<?php 
			  		// get student per their respective group
			  	$stud_row = $obj->show_student($row['Student_group']);
                 $srno = 0;

			  	foreach ($stud_row as $data) {
              $srno ++;
			  		?>
			  	<tr>
			  		 <td><?php echo $srno;   ?></td>
			  		<td><?php echo $data['Fullname']  ?></td>
			  		<td><?php 
                              

			  		echo $obj->students_age($data['Dob']).' years age';   ?></td>
			  		<td><?php echo $data['Student_id']  ?></td>
			  		<td><?php echo $data['Date']  ?></td>
 			  	</tr>
			  <?php } ?>
			   <?php } ?>

			<?php }else{ echo "no datas";?>
			  </tbody>
			<?php }?>
		  </table>

<hr>

		  <h3>Students Datas</h3>
		<h6>2. The age of the oldest member in each group.</h6>

		<hr>
		 <table class="table table-responsive table-hover" border="2">
			  
			  <thead>
			  	<th>#</th>
			  	<th>Fullname</th>
			  	<th>DOB</th>
			  	<th>Student ID</th>
			  	<th>Added date</th>
			  </thead>

			  <tbody>

			  	<?php 
			  	$obj = new Main;
                   //  get all student but diplay only group name
			  	$data = $obj->show_groups();
                 $srno = 0;
         if ($data > 0) {
            foreach ($data as $row) {
              $srno ++;

			  		?>
			  		<tr>
			  			<td  colspan="6"  align="center" style="background: #f2f2f2; color:green; font-weight: bolder;"><?php echo $row['Student_group']  ?></td>
			  		</tr>
			  		<?php 
			  		// get student with highest age in a 		 group
			   	$data_row = $obj->oder_age($row['Student_group']);
  
                ?>
			  	<tr> 
			  		<td><?php  echo  $srno ?></td>

			  		<td><?php echo $data_row['Fullname']  ?></td>
			  		<td><?php 
                            echo $data_row['Age'] 

                             ?></td>
			  		<td><?php echo $data_row['Student_id']  ?></td>
			  		<td><?php echo $data_row['Date']  ?></td>
 			  	</tr>

			
			   <?php } ?>

			<?php }else{ echo "no datas";?>
			  </tbody>
			<?php }?>
		  </table>

  <hr>

		  		  <h3>Students Datas</h3>
		<h6>3. The sum of ages of students in each group.</h6>

		<hr>
		 <table class="table table-responsive table-hover" border="2">
			  
			  <thead>
			  	<th colspan="6"  align="center">Total age</th>
			  	
			  </thead>

			  <tbody>

			  	<?php 
			  	$obj = new Main;
                   //  get all student but diplay only group name
			  	$data = $obj->show_groups();
                 $srno = 0;
         if ($data > 0) {
            foreach ($data as $row) {
              $srno ++;

			  		?>
			  		<tr>
			  			<td  colspan="6"  align="center" style="background: #f2f2f2; color:green; font-weight: bolder;"><?php echo $row['Student_group']  ?></td>
			  		</tr>
			  		<?php 
			  		// sum of age in a group
			   	$data_r = $obj->sum_age($row['Student_group']);
                ?>
			  	<tr> <td colspan="6"  align="center"><?php 
                            echo $data_r['total_age'] 

                             ?></td>
 			  	</tr>

			
			   <?php } ?>

			<?php }else{ echo "no datas";?>
			  </tbody>
			<?php }?>
		  </table>

		      <hr>
		<h3>Students Datas</h3>
		<h6>4. The regNo of students in each group in ascending order.</h6>

		<hr>
		 <table class="table table-responsive table-hover" border="2">
			  
			  <thead>
			  	<th>RegNo</th>
			  	
			  </thead>

			  <tbody>

			  	<?php 
			  	$obj = new Main;
                   //  get all student but diplay only group name
			  	$data = $obj->show_groups();
                 $srno = 0;
         if ($data > 0) {
            foreach ($data as $row) {
              $srno ++;
			  		?>
			  		<tr>
			  			<td  colspan="6"  align="center" style="background: #f2f2f2; color:green; font-weight: bolder;"><?php echo $row['Student_group']  ?></td>
			  		</tr>
			  		<?php 
			  		// get student per their respective group
			  	$stud_row = $obj->show_student($row['Student_group']);
                 $srno = 0;

			  	foreach ($stud_row as $data) {
              $srno ++;
			  		?>
			  	<tr>
			  		<td colspan="6"  align="center"> <?php echo $data['Student_id']  ?></td>
			  			  	</tr>
			  <?php } ?>
			   <?php } ?>

			<?php }else{ echo "no datas";?>
			  </tbody>
			<?php }?>
		  </table>
	</fieldset>

</body>
</html>